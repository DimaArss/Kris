import bodyParser from "body-parser"
import express from "express"
import mongoose from "mongoose"
import path from "path"
import authRouter from "./authRouter.js"
import card from "./Models/card.js"
import User from "./Models/User.js"


const app = express()
const port = 4000
const __dirname = path.resolve()
const start = async ()=>{
    try {
        await mongoose.connect('mongodb+srv://adm:adm@klaster0.iotabh6.mongodb.net/?retryWrites=true&w=majority')
        app.use(bodyParser.urlencoded({extended: true}))
        app.use(bodyParser.json());
        app.use(express.static('views'))
        app.use(express.json())
        app.use('/auth', authRouter)
        app.set('views', path.resolve(__dirname, 'views'))
        app.set('view engine', 'ejs')

        app.get('/', (req, res) => {
            User.find()
            .then(result =>{
                res.render("pages/index", {data:result})
                console.log(result);
            })
        })
        app.post('/newcard', async (req, res) =>{
            const img = "800x800.png"
            const title = "Товар 5"
            const subtitle = "описание"
            const coast = "100"
            const newproduct = new card({img: img, thagolovok: title, pod_thagolovok: subtitle, chena: coast})
            await newproduct.save()
        })
        app.listen(port, () => console.log(`Example app listening on port ${port}!`))     
    } catch (error) {
        
    }
}
start()