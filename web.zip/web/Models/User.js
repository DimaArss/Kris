import { Schema, model } from "mongoose"

const User = new Schema({
    password: {type: String, unique: true, required: true},
    telephone: {type: Number, required: true, trim: true },
})
export default model('User', User)