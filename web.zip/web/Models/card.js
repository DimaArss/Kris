import { Schema, model } from "mongoose"

const Card = new Schema({
    img: {type: String, required: true, trim: true, unique: true},
    thagolovok: {type: String, required: true, trim: true, unique: true},
    pod_thagolovok: {type: String, required: true, trim: true},
    chena: {type: Number, required: true, trim: true},
})
export default model('Card', Card)