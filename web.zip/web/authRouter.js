import card from "./Models/card.js"
import controller from "./authController.js"
import Router from "express"


const router = new Router()

router.get('/about',(req, res) =>{
    res.render('pages/about')
})

router.get('/shop',(req, res) =>{
    card.find()
    .then(result => {
        res.render('pages/shop',{data: result})
    })
})

router.get('/contact',(req, res) =>{
    res.render('pages/contact')
})

router.get('/registration',(req, res) =>{
    res.render('pages/register')
})
router.post('/registration', controller.registration)

router.get('/authorization', (req, res) =>{
    res.render('pages/login')
})
router.post('/authorization', controller.authorization)

export default router