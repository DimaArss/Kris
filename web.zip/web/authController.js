import bodyParser from "body-parser"
import User from "./Models/User.js"


class authController{
    async registration (req, res) {
        try {
            const { telephone, password } = req.body
            const isUser = await User.findOne({telephone})
            if(isUser){
                res.send('Пользователь с таким номером телефона уже зарегестрирован')
                // res.status(404).json("Пользователь с таким номером телефона уже зарегестрирован")
            }
            const user = new User({password: password, telephone: telephone})
            await user.save()
            res.redirect('/')
        } catch (error) {
            console.log(error)
            res.status(400).json(error)
        }
    }
    async authorization (req, res) {
        try {
            const { phone, pass } = req.body
            const user = await User.findOne({phone})
            if(!user) {
                res.status(400)
            }
            res.redirect('/')
        } catch (error) {
            console.log(error)
            res.status(400).json(error)
        }
    }
}
export default new authController